function showSubmenu(submenuId) {
    var submenuToShow = document.getElementById(submenuId);
    if (submenuToShow) {
        submenuToShow.style.display = 'block';
    }
}
